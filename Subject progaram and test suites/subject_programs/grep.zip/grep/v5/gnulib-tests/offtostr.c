/* -*- buffer-read-only: t -*- vi: set ro: */
/* DO NOT EDIT! GENERATED AUTOMATICALLY! */
#define anytostr offtostr
#define inttype off_t
#define inttype_is_signed 1
#include "anytostr.c"
