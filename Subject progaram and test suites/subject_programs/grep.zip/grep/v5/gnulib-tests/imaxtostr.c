/* -*- buffer-read-only: t -*- vi: set ro: */
/* DO NOT EDIT! GENERATED AUTOMATICALLY! */
#define anytostr imaxtostr
#define inttype intmax_t
#define inttype_is_signed 1
#include "anytostr.c"
