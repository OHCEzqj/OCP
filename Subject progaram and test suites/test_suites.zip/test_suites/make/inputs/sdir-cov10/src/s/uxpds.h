/* Handle uxpds  */

#include "usg5-4-2.h"

/* This triggers a conditional in xfaces.c.  */
#define XOS_NEEDS_TIME_H

#define FSCALE 256
