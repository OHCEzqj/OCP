/* Definitions file for GNU Emacs running on Sony's NEWS-OS 6.x  */

#include "usg5-4-2.h"

#define NEWSOS6
#define HAVE_TEXT_START
