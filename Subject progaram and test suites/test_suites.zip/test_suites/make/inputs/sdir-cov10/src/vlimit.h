/* Dummy for Emacs so that we can run on VMS... */
#define LIM_DATA 0
