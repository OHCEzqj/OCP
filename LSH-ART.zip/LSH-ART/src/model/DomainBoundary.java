package model;

import java.util.ArrayList;

//������ķ�Χ
public class DomainBoundary {
	ArrayList<MyDimension> BoundaryData;

	public DomainBoundary() {
		// TODO Auto-generated constructor stub
		BoundaryData = new ArrayList<MyDimension>();
	}

	/*
	 * n��ά�ȸ��� Ĭ��ÿ��ά�ȷ�Χ����min~max
	 */
	public DomainBoundary(int n, double min, double max) {
		// TODO Auto-generated constructor stub
		BoundaryData = new ArrayList<MyDimension>();
		for (int i = 0; i < n; i++) {
			BoundaryData.add(new MyDimension(min, max));
		}
	}

	public DomainBoundary(ArrayList<MyDimension> domainboundary) {
		// TODO Auto-generated constructor stub
		BoundaryData = domainboundary;
	}
	
	//�������캯��
	public DomainBoundary(DomainBoundary domainboundary) {
		// TODO Auto-generated constructor stub
		this.BoundaryData=new ArrayList<MyDimension>();
		double min,max;
		for(int i=0;i<domainboundary.SizeOfInputDomain();i++)
		{
			min=domainboundary.getDimension(i).getMin();
			max=domainboundary.getDimension(i).getMax();
			this.BoundaryData.add(new MyDimension(min, max));
		}
	}
	

	/*
	 * ��ȡ��i��ά�ȵķ�Χ
	 */
	public MyDimension getDimension(int i) {
		return this.BoundaryData.get(i);
	}

	/*
	 * ���õ�i��ά�ȵķ�Χ
	 */
	public void setDimension(int i, MyDimension dim) {
		this.BoundaryData.set(i, dim);
	}

	/*
	 * ��ȡά�ȸ���
	 */
	public int SizeOfInputDomain() {
		return this.BoundaryData.size();
	}
	
	/*
	 * ����һ��ά��
	 */
	public void addDimension(MyDimension newDim) {
		this.BoundaryData.add(newDim);
	}
	
	public ArrayList<MyDimension> getList() {
		return this.BoundaryData;
	}
	public void setList(ArrayList<MyDimension> dimlist) {
		this.BoundaryData=dimlist;
	}
}
