package model;


public class MyDimension {
	double min; 
	double max;
	double range;
	public MyDimension(double min,double max) {
		this.min=min;
		this.max=max;
		range=max-min;
	}
	public double getMin() {
		return min;
	}
	public void setMin(double min) {
		this.min = min;
	}
	public double getMax() {
		return max;
	}
	public void setMax(double max) {
		this.max = max;
	}
	public double getRange() {
		return range;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated constructor stub
		return "min="+min+",max="+max;
	}
}
