package model;


import java.util.ArrayList;

import com.mathworks.toolbox.javabuilder.MWArray;
import com.mathworks.toolbox.javabuilder.MWClassID;
import com.mathworks.toolbox.javabuilder.MWNumericArray;

import getRexp.CallForW;
import model.*;
public class CreateW {

	private double p1;//��ײ����
	public CreateW(double p1) {
		this.p1=p1;
	}
	
	public double callMatlab(ArrayList<MyDimension> dimList){
    	double r1=0;
    	for(int i=0;i<dimList.size();i++)
    		r1+=dimList.get(i).getRange()*dimList.get(i).getRange();
    	
    	r1=Math.sqrt(r1)/2;

        CallForW funCallForW=null;
        MWNumericArray p=null;
        MWNumericArray res=null;
        Object[] rexp=null;
        double w=0;
        //����getRexp����
        try {
        	funCallForW=new CallForW();
        	p=new MWNumericArray(p1);
        	rexp=funCallForW.getRexp(1, p);
        	double rexp1=Double.parseDouble(rexp[0].toString());
        	//System.out.println("The rexp is:"+rexp1);
        	w=r1/rexp1;
        }catch (Exception e) {
			// TODO: handle exception
        	System.out.println("Exception: " + e.toString());  
        	//System.exit(0);
		}finally {
		//�ر�����
			MWArray.disposeArray(p);
			MWArray.disposeArray(rexp);
			if (funCallForW!= null) {
				funCallForW.dispose();
			}
		}
        return w;
    }
	
    /*
	 * @paramter p1: ���Ƶ�����ͬһ��Ͱ����С����
	 * @paramter p2: ��ͬ�ĵ����ڲ�ͬͰ�ĸ���
	 * @r1  :  �ȽϽ��ľ���
	 * @r2  :  �Ƚ�Զ�ľ���
	 * @dimList:  ��ά�ȵ�ȡֵ��Χ
	 */
   
}
