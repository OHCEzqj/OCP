package model;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Random;
import model.*;

public class LSH {
	private int dimension;
	private ArrayList<Double> a=new ArrayList<Double>();
	private double b;
	private double w=10;
	
	private Random random=new Random();
	
	public LSH() {
		// TODO Auto-generated constructor stub
		dimension=0;
	}
	
	public LSH(int dim) {
		this.dimension=dim;
		for(int i=0;i<dim;i++)
			a.add(random.nextGaussian());
		b=random.nextDouble()*w;
	}
	public LSH(int dim,double w) {
		this.w=w;
		this.dimension=dim;
		for(int i=0;i<dim;i++)
			a.add(random.nextGaussian());
		b=random.nextDouble()*w;
	}
	
	public double getLSH_val(ArrayList<Double> x)//Ĭ��Ϊx��ά��һ������LSH��a��ά��
	{
		double LSH_val=0;
		for(int i=0;i<dimension;i++)
			LSH_val+=a.get(i)*x.get(i);
		LSH_val+=b;
		LSH_val/=w;
		LSH_val=Math.floor(LSH_val);//����ȡ��
		return LSH_val;
	}
	
	public double getLSH_val(Testcase x)//Ĭ��Ϊx��ά��һ������LSH��a��ά��
	{
		ArrayList<Double> data=x.list;
		double LSH_val=0;
		for(int i=0;i<dimension;i++)
			LSH_val+=a.get(i)*data.get(i);
		LSH_val+=b;
		LSH_val/=w;
		
		return Math.floor(LSH_val);//����ȡ��
	}
	
	public int getDimension() {
		return dimension;
	}

	public void setDimension(int dimension) {
		this.dimension = dimension;
		for(int i=0;i<dimension;i++)
			a.add(random.nextGaussian());
		b=random.nextDouble()*w;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String reString="a=";
		for(int i=0;i<dimension;i++)
			reString=reString+a.get(i)+", ";
		reString=reString+"\tb="+b+", w="+w+"\r\n";
		return reString;
	}
	
	public double getW() {
		return w;
	}

	public void setW(double w) {
		this.w = w;
		b=random.nextDouble()*w;
	}

	public ArrayList<Double> getA() {
		return a;
	}

	public double getB() {
		return b;
	}

	public static double getFirstW(ArrayList<MyDimension> list) {
		CreateW w = new CreateW(0.9);
		double firstW = w.callMatlab(list);
		return firstW;
	}

}
